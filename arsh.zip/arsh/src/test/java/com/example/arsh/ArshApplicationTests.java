package com.example.arsh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArshApplicationTests {

	@Test
	void contextLoads() {
	}

}
