package service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.Student;
import repo.repository;

@Service
public class studentService {
	
	@Autowired
	repository r;
	
	public boolean saveStudent(Student s) {
		return r.save(s) != null ? true : false;
	}
 
}
