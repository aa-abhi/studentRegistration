package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import model.Student;
import service.studentService;

@RestController
@CrossOrigin
public class studentController {
	
	@Autowired
	studentService s;
	
	@PostMapping(path = "/register")
	public boolean registerStudent(Student st) {
		return s.saveStudent(st);
	}
	
}
